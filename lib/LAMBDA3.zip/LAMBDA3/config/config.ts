export interface Config {
    adminboundaries: string;
    geocodedaddressing: string;

}

