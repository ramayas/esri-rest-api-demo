export interface AddressDTO {
    location: string;
    suburbname: string;
    districtName: string;
}